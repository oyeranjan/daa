import java.util.Scanner;
public class Addmatrix
{
    public static void main(String[] args) 
    {
        int p, q;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number of rows in matrix:");
        p = s.nextInt();
        System.out.print("Enter number of columns in matrix:");
        q = s.nextInt();

            int a[][] = new int[p][q];
            int b[][] = new int[p][q];
            int c[][] = new int[p][q];
            System.out.println("Enter all the elements of first matrix:");
            for (int i = 0; i < p; i++) 
            {
                for (int j = 0; j < q; j++) 
                {
                    a[i][j] = s.nextInt();
                }
            }
            System.out.println("Enter all the elements of second matrix:");
            for (int i = 0; i < p; i++) 
            {
                for (int j = 0; j < q; j++) 
                {
                    b[i][j] = s.nextInt();
                }
            }
            
            for (int i = 0; i < p; i++) 
            {
                for (int j = 0; j < q; j++) 
                {
                 
                        c[i][j] = a[i][j] + b[i][j];
                 }
            }
            System.out.println("Matrix after addition:");
            for (int i = 0; i < p; i++) 
            {
                for (int j = 0; j < q; j++) 
                {
                    System.out.print(c[i][j]+" ");
                }
                System.out.println("");
            }
    }
}
