import java.io.*;
import java.util.*;

public class Findlargestsmallest
 {
 
	public static void main(String[] args)
	 {
		int numbers[] = new int[]{1,2,3,5,7,8,9,10,15,45,4,11};
		int smallest = numbers[0];
		int largetst = numbers[0];
		
		for(int i=1; i< numbers.length; i++)
		{
			if(numbers[i] > largetst)
				largetst = numbers[i];
			else if (numbers[i] < smallest)
				smallest = numbers[i];
			
		}
		
		System.out.println("Largest Number is : " + largetst);
		System.out.println("Smallest Number is : " + smallest);
	}
}
