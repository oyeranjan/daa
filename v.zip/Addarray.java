import java.io.*;
import java.util.*;
public class Addarray
{
public static void main(String args[])
{
int a[]=new int[5];
int sum=0;
int i;
System.out.println("enter the elements of array: ");
Scanner sc=new Scanner(System.in);
for(i=0;i<5;i++)
{
	a[i]=sc.nextInt();
}
for(i=0;i<5;i++)
{
	sum=sum+a[i];
}
System.out.println("Sum= "+sum);
}
}


