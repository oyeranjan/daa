import java.io.*;
import java.util.*;
public class Even
{
public static void main(String args[])
{
int a[]=new int[10];
Scanner sc=new Scanner(System.in);
System.out.println("Enter the elements of array: ");
for(int i=0;i<10;i++)
	a[i]=sc.nextInt();

for(int i=0;i<10;i++)
{
while(a[i] % 2 == 0)
{
	
		System.out.println("Even number is: "+a[i]);
		break;
}
}
}
}


