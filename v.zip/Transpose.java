import java.util.Scanner;
 
class TransposeAMatrix
{
   public static void main(String args[])
   {
      int n, m, i, j;
 
      Scanner in = new Scanner(System.in);
      System.out.println("Enter the number of rows and columns of matrix");
      n = in.nextInt();
      m = in.nextInt();
 
      int matrix[][] = new int[n][m];
 
      System.out.println("Enter the elements of matrix");
 
      for (i = 0; i < n; i++)
         for (j = 0; j < m; j++)
            matrix[i][j] = in.nextInt();
 
      int transpose[][] = new int[m][n];
 
      for (i = 0; i < n; i++)
         for (j = 0; j < m; j++)               
            transpose[j][i] = matrix[i][j];
 
      System.out.println("Transpose of the matrix:");
 
      for (i = 0; i < n; i++)
      {
         for (j = 0; j < m; j++)
               System.out.print(transpose[i][j]+"\t");
 
         System.out.print("\n");
      }
   }
}
